#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//incarc un sir de lungime egala cu sirul dat cu spatiu
void spatiu(char *s, int n)
{
    for(int i = 0; i < n; i++)
        s[i] = ' ';
    s[n] = NULL;
}
void highlight(char *s, char *g)
{
    int in, sf, i;
    char *p, *r, v[100], *h;
    spatiu(v, strlen(s));
    h = (char *)malloc((strlen(s)+ 1) * sizeof(char));
    strcpy(h, v);
    p = (char *)malloc((strlen(s)+ 1) * sizeof(char));
    char a[][20] = {"or", "first", "from", "in", "is", "unit", "for", "while", "int", "float", "double", "string", "list"};
    for(i = 0; i < 13; i++)
    {
        if(strstr(s, a[i]))
        {
            // verific daca este la inceput de rand
            if(strlen(s) == strlen(strstr(s, a[i])))
            {
                // cazurile pentru 2 cuvinte
                if(strchr(a[i], 'first') && strstr(strstr(s,a[i]), "of"))
                {
                    int b, e, k = 0, o;
                    b = strlen(s) - strlen(strstr(s,a[i])) + strlen("first");
                    e = strlen(s) - strlen(strstr(strstr(s,a[i]), "of"));
                    for(o = b; o < e; o++)
                    {
                        if(s[o] != ' ')
                        {
                            k = 1;
                            break;
                        }
                    }
                    if(k == 0)
                    {
                        in = strlen(s) - strlen(strstr(s,a[i]));
                        sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "of")) + 2;
                        for(int j = in; j < sf; j ++)
                            h[j] = '_';
                    }
                }
                else if(strchr(a[i], 'list') && strstr(strstr(s,a[i]), "of"))
                {
                    int b, e, k = 0, o;
                    b = strlen(s) - strlen(strstr(s,a[i])) + strlen("list");
                    e = strlen(s) - strlen(strstr(strstr(s,a[i]), "of"));
                    for(o = b; o < e; o++)
                    {
                        if(s[o] != ' ')
                        {
                            k = 1;
                            break;
                        }
                    }
                    if(k == 0)
                    {
                        in = strlen(s) - strlen(strstr(s,a[i]));
                        sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "of")) + 2;
                        for(int j = in; j < sf; j ++)
                            h[j] = '_';
                    }
                }
                else if(strchr(a[i], 'is') && strstr(strstr(s,a[i]), "a "))
                {
                    int b, e, k = 0, o;
                    b = strlen(s) - strlen(strstr(s,a[i])) + strlen("is");
                    e = strlen(s) - strlen(strstr(strstr(s,a[i]), "a"));
                    for(o = b; o < e; o++)
                    {
                        if(s[o] != ' ')
                        {
                            k = 1;
                            break;
                        }
                    }
                    if(k == 0)
                    {
                        in = strlen(s) - strlen(strstr(s,a[i]));
                        sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "a")) + 1;
                        for(int j = in; j < sf; j ++)
                            h[j] = '_';
                    }
                }
                else if(strchr(a[i], 'for') && strstr(strstr(s,a[i]), "each"))
                {
                    int b, e, k = 0, o;
                    b = strlen(s) - strlen(strstr(s,a[i])) + strlen("for");
                    e = strlen(s) - strlen(strstr(strstr(s,a[i]), "each"));
                    for(o = b; o < e; o++)
                    {
                        if(s[o] != ' ')
                        {
                            k = 1;
                            break;
                        }
                    }
                    if(k == 0)
                    {
                        in = strlen(s) - strlen(strstr(s,a[i]));
                        sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "each")) + 4;
                        for(int j = in; j < sf; j ++)
                            h[j] = '_';
                    }
                }
                // sublinierea pentru un cuvant
                else if(s[strlen(a[i])] == ' ')
                {
                    in = strlen(s) - strlen(strstr(s, a[i]));
                    sf = in + strlen(a[i]);
                    for(int j = in; j < sf; j ++)
                        h[j] = '_';
                }
            }
            // cazul in care sintaxa se afla inainte de spatiu
            else if(s[strlen(s) - strlen(strstr(s, a[i])) - 1] == ' ')
            {
                // daca se afla la sfarsitul sirului
                if((strlen(s) - strlen(strstr(s, a[i]) + strlen(a[i])) == strlen(s)))
                {
                    // first si list nu vor fi subliniate
                    if(strstr(a[i],"first") || strstr(a[i],"list"))
                        continue;
                    // subliniez daca sunt celelalte cuvinte
                    else
                    {
                        in = strlen(s) - strlen(strstr(s, a[i]));
                        sf = in + strlen(a[i]);
                        for(int j = in; j < sf; j ++)
                            h[j] = '_';
                    }
                }
                // daca exista sintaxa la mijloc
                if(s[strlen(s) - strlen(strstr(s, a[i]) + strlen(a[i]))] == ' ')
                {
                    //cazurile pentru 2 cuvinte
                    if(strchr(a[i], 'first') && strstr(strstr(s,a[i]), "of"))
                    {
                        int b, e, k = 0, o;
                        b = strlen(s) - strlen(strstr(s,a[i])) + strlen("first");
                        e = strlen(s) - strlen(strstr(strstr(s,a[i]), "of"));
                        for(o = b; o < e; o++)
                        {
                            if(s[o] != ' ')
                            {
                                k = 1;
                                break;
                            }
                        }
                        if(k == 0)
                        {
                            in = strlen(s) - strlen(strstr(s,a[i]));
                            sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "of")) + 2;
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                    }
                    else if(strchr(a[i], 'list') && strstr(strstr(s,a[i]), "of"))
                    {
                        int b, e, k = 0, o;
                        b = strlen(s) - strlen(strstr(s,a[i])) + strlen("list");
                        e = strlen(s) - strlen(strstr(strstr(s,a[i]), "of"));
                        for(o = b; o < e; o++)
                        {
                            if(s[o] != ' ')
                            {
                                k = 1;
                                break;
                            }
                        }
                        if(k == 0)
                        {
                            in = strlen(s) - strlen(strstr(s,a[i]));
                            sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "of")) + 2;
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                    }
                    else if(strchr(a[i], 'is') && strstr(strstr(s,a[i]), "a "))
                    {
                        int b, e, k = 0, o;
                        b = strlen(s) - strlen(strstr(s,a[i])) + strlen("is");
                        e = strlen(s) - strlen(strstr(strstr(s,a[i]), "a"));
                        for(o = b; o < e; o++)
                        {
                            if(s[o] != ' ')
                            {
                                k = 1;
                                break;
                            }
                        }
                        if(k == 0)
                        {
                            in = strlen(s) - strlen(strstr(s,a[i]));
                            sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "a")) + 1;
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                        else
                        {
                            in = strlen(s) - strlen(strstr(s, a[i]));
                            sf = in + strlen(a[i]);
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                    }
                    else if(strchr(a[i], 'for') && strstr(strstr(s,a[i]), "each"))
                    {
                        int b, e, k = 0, o;
                        b = strlen(s) - strlen(strstr(s,a[i])) + strlen("for");
                        e = strlen(s) - strlen(strstr(strstr(s,a[i]), "each"));
                        for(o = b; o < e; o++)
                        {
                            if(s[o] != ' ')
                            {
                                k = 1;
                                break;
                            }
                        }
                        if(k == 0)
                        {
                            in = strlen(s) - strlen(strstr(s,a[i]));
                            sf = strlen(s) - strlen(strstr(strstr(s,a[i]), "each")) + 4;
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                        else
                        {
                            in = strlen(s) - strlen(strstr(s, a[i]));
                            sf = in + strlen(a[i]);
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                        }
                    }
                    else
                    {
                        // in cazul in care first si list sunt simple, continui
                        if(strstr(a[i],"first") || strstr(a[i],"list"))
                            continue;
                        else
                        {
                            //subliniez cuvintele
                            in = strlen(s) - strlen(strstr(s, a[i]));
                            sf = in + strlen(a[i]);
                            for(int j = in; j < sf; j ++)
                                h[j] = '_';
                            /*verific daca in subsirul dat de strstr mai exista cuvinte de subliniat
                            si apelez functia recursiv pt a le cauta*/
                            strcpy(p, &s[strlen(s) - strlen(strstr(s, a[i])) + strlen(a[i])]);
                            spatiu(v, strlen(p));
                            r = (char *)malloc((strlen(p)+ 1) * sizeof(char));
                            strcpy(r, v);
                            highlight(p, r);
                            strcpy(&h[strlen(h) - strlen(r)], r);
                        }
                    }
                }
            }
            // in cazul in care inainte de subsirul generat de strstr nu este spatiu
            else if(s[strlen(s) - strlen(strstr(s, a[i])) - 1] != ' ')
            {
                {
                    /*verific daca in subsirul dat de strstr mai exista cuvinte de subliniat
                    si apelez functia recursiv pt a le cauta*/
                    strcpy(p, &s[strlen(s) - strlen(strstr(s, a[i])) + 1]);
                    spatiu(v, strlen(p));
                    r = (char *)malloc((strlen(p)+ 1) * sizeof(char));
                    strcpy(r, v);
                    highlight(p, r);
                    strcpy(&h[strlen(h) - strlen(r)], r);
                }
            }
        }
    }
    //salvez de la pozitia aflata pozitiile unde trebuie sa fie subliniat
    strcpy(&g[strlen(g) - strlen(h)], h);
}
int main()
{
    char sir[100], sp[100];
    int n, i;
    char *s, *high;
    scanf("%d", &n);
    getchar();
    for(i = 0; i < n; i++)
    {
        gets(sir);
        s = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        strcpy(s, sir);
        spatiu(sp, strlen(sir));
        high = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        strcpy(high, sp);
        highlight(s, high);
        printf("%s\n", s);
        printf("%s\n", high);
        free(s);
        free(high);
    }
    return 0;
}
