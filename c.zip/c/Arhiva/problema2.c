#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct dictionar
{
    char *w;
    int pri;
} dict;
// aloc dinamic cuvintele
void add(dict *v, int i, char *cuv)
{
    v[i].w=(char *)malloc(strlen(cuv)*sizeof(char));
    strcpy(v[i].w, cuv);
    v[i].pri = 0;
}
int find(char *s, dict *d, int n)
{
    int i, k = 0, poz = 0;
    char cuv[20] = "zzzzzzzzzzzzzzzzzzzz";
    for(i = 0; i < n; i++)
    {
        // verific daca s este inclus in d[i].w
        if(strstr(d[i].w, s))
        {
            // verific daca s este la inceputul lui d[i].w
            if(strlen(d[i].w) - strlen(strstr(d[i].w, s)) == 0)
                // il aleg pe cel cu cea mai mare prioritate
                if(d[i].pri == poz)
                {
                    // verific daca d[i].w este mai mic lexicografic ca si cuv si il incarc pe cuv cu atributele lui d[i]
                    if(strcmp(d[i].w, cuv) <= 0)
                    {
                        strcpy(cuv, d[i].w);
                        k = i;
                        poz = d[i].pri;
                    }
                }
                else if(d[i].pri > poz)
                {
                    strcpy(cuv, d[i].w);
                    k = i;
                    poz = d[i].pri;
                }
        }
    }
    // daca s este subsir al lui cuv, returnez pozitia din dictionar
    if(strstr(cuv, s))
        return k;
    else return -1;
}
int main()
{
    dict *v;
    int n, i, m, star = 0, k, nr;
    char cuv[25];
    scanf("%d", &n);
    nr = n;
    getchar();
    v = (dict*)malloc(n*sizeof(dict));
    for(i = 0; i < n; i++)
    {
        scanf("%s", cuv);
        // adaug cuvintele in dictionar
        add(v, i, cuv);
    }
    scanf("%d", &m);
    getchar();
    for(i = 0; i < m; i++)
    {
        scanf("%s", cuv);
        star = 0;
        // verific semnele de punctuatie si le afisez
        if(strchr(cuv,'.') || strchr(cuv,',') ||strchr(cuv,':') ||strchr(cuv,'!') ||strchr(cuv,'?'))
            printf("%s ", cuv);
        else
        {
            // verific daca are *
            if(strstr(cuv,"*"))
            {
                star = 1;
                cuv[strlen(cuv) - strlen(strstr(cuv,"*"))] = NULL;
            }
            // caut cuvantul in dictionar
            k = find(cuv, v, nr);
            if(k != -1)
            {
                if(star == 0)
                {
                    // daca cuv este in dictinar si nu are * il afisez
                    printf("%s ", v[k].w);
                    v[k].pri++;
                }
                else
                {
                    // verific existenta in dictionar
                    if(strcmp(cuv, v[k].w) == 0)
                    {
                        // daca este in dictionar si are * afizez ce e inaintea *
                        printf("%s ", cuv);
                        v[k].pri++;
                    }
                    // daca nu este in dictionar
                    else
                    {
                        // maresc marimea dictionarului
                        nr ++;
                        // realochez dinamic
                        v = (dict*)realloc(v, nr*sizeof(dict));
                        // adaug cuvantul
                        add(v, nr - 1, cuv);
                        // ii maresc prioritatea in dictionar
                        v[nr - 1].pri ++;
                        // il afisez
                        printf("%s ", v[nr - 1].w);
                    }
                }
            }
            // daca nu este in dictionar
            else
            {

                nr ++;// maresc marimea dictionarului
                // realochez dinamic
                v = (dict*)realloc(v, nr*sizeof(dict));
                // adaug cuvantul
                add(v, nr - 1, cuv);
                // ii maresc prioritatea in dictionar
                v[nr - 1].pri ++;
                // il afisez
                printf("%s ", v[nr - 1].w);
            }
        }
    }
    return 0;
}
