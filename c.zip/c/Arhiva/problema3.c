#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct calcule
{
    int cif[4], cod[2];
} calc;
void sum(calc *v, int n)
{
    int nr = 0;
    for(int i = 3; i >= 0; i--)
    {
        /*calculez in nr suma pe bite conform cerintei
        Adica, nu mai iau in calcul ultimul bite ce imi ramane*/
        nr = nr + v[n + 1].cif[i] + v[n].cif[i];
        v[n + 1].cif[i] = nr % 2;
        nr = nr / 2;
    }
}
void swich(calc *v, int n)
{
    int a, b, c;
    // aflu pozitiile in a si b
    a = v[n + 1].cif[0] * 2 + v[n + 1].cif[1];
    b = v[n + 1].cif[2] * 2 + v[n + 1].cif[3];
    //fac inlocuirea dupa pozitiile aflate
    c = v[n].cif[b];
    v[n].cif[b] = v[n].cif[a];
    v[n].cif[a] = c;
    //incarc noul numar
    for(int i = 0; i < 4; i++)
        v[n + 1].cif[i] = v[n].cif[i];
}
void left(calc *v, int n)
{
    int ct, nr;
    //calculez de cate ori trebuie rotit
    ct = v[n + 1].cif[0] * 8 + v[n + 1].cif[1] * 4 +v[n + 1].cif[2] * 2 + v[n + 1].cif[3];
    //o data la 4 ciclari numarul ramane la fel
    ct = ct % 4;
    //rotesc numarul
    while(ct)
    {
        //salvez prima cifra ca sa o pun la final
        nr = v[n].cif[0];
        for(int i = 0; i < 3; i++)
            v[n].cif[i] = v[n].cif[i + 1];
        v[n].cif[3] = nr;
        ct--;
    }
    //incarc noul numar
    for(int i = 0; i < 4; i++)
        v[n + 1].cif[i] = v[n].cif[i];
}
void xor(calc *v, int n)
{
    for(int i = 0; i < 4; i++)
    {
        /*in cazul in cate bite de pe aceleasi pozitii
        sunt diferiti pozitia se incarca cu 1
        daca nu pozitia se incarca cu 0*/
        if(v[n + 1].cif[i] != v[n].cif[i])
            v[n + 1].cif[i] = 1;
        else
            v[n + 1].cif[i] = 0;
    }
}
int main()
{
    calc *v;
    int n, i, ct =  0, k = 0, nr = 0, x;
    unsigned int a;
    scanf("%d%d", &n, &a);
    v = (calc*)malloc((n * 6 + 4)*sizeof(calc));
    int b[32];
    //generez ultimele n * 6 + 4 cifre din baza 10
    while(ct < n * 6 + 4)
    {
        b[ct] = (a % 2);
        a /= 2;
        ct++;
    }
    for(i = n * 6 + 3; i >= 0; i--)
    {
        if(k < 6)
        {
            if(ct == 0)
                //aflu numerele in baza 2
                v[nr].cif[k] = b[i];
            else
                //aflu codul pt operatie
                v[nr].cod[k - 4] = b[i];
            k++;
        }
        if(k == 4)
            ct = 1;
        if(k == 6)
        {
            k = 0;
            ct = 0;
            nr++;
        }
    }
    for(i = 0; i < nr; i++)
    {
        //verific ce operatii trebuie sa realizez
        if(v[i].cod[0] == 0 && v[i].cod[1] == 0)
            sum(v, i);
        if(v[i].cod[0] == 0 && v[i].cod[1] == 1)
            swich(v, i);
        if(v[i].cod[0] == 1 && v[i].cod[1] == 0)
            left(v, i);
        if(v[i].cod[0] == 1 && v[i].cod[1] == 1)
            xor(v, i);
    }
    //transform numarul din baza 2 in baza 10
    x = v[nr].cif[0] * 8 + v[nr].cif[1] * 4 +v[nr].cif[2] * 2 + v[nr].cif[3];
    printf("%d", x);
    return 0;
}
