#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void spatiu(char *s, int n)
{
    for(int i = 0; i < n; i++)
        s[i] = ' ';
    s[n] = NULL;
}
void highlight(char *s, char *g)
{
    int in, sf, i;
    char *p, *r, v[100], *h;
    spatiu(v, strlen(s));
    h = (char *)malloc((strlen(s)+ 1) * sizeof(char));
    strcpy(h, v);
    p = (char *)malloc((strlen(s)+ 1) * sizeof(char));
    char a[][20] = {"for", "from", "in", "is", "unit", "or", "while", "int", "float", "double", "string", "first", "list"};
    for(i = 0; i < 11; i++)
    {
        if(strstr(s, a[i]))
        {
            if(strlen(s) == strlen(strstr(s, a[i])))
            {
                in = strlen(s) - strlen(strstr(s, a[i]));
                sf = in + strlen(a[i]);
                for(int j = in; j < sf; j ++)
                    h[j] = '_';
            }
            else if(s[strlen(s) - strlen(strstr(s, a[i])) - 1] == ' ')
            {
                if((strlen(s) - strlen(strstr(s, a[i]) + strlen(a[i])) == strlen(s)))
                {
                    in = strlen(s) - strlen(strstr(s, a[i]));
                    sf = in + strlen(a[i]);
                    for(int j = in; j < sf; j ++)
                        h[j] = '_';
                }
                else if(s[strlen(s) - strlen(strstr(s, a[i]) + strlen(a[i]))] == ' ')
                {
                    in = strlen(s) - strlen(strstr(s, a[i]));
                    sf = in + strlen(a[i]);
                    for(int j = in; j < sf; j ++)
                        h[j] = '_';
                }
            }
            else if(s[strlen(s) - strlen(strstr(s, a[i])) - 1] != ' ')
            {
                if(s[strlen(s) - strlen(strstr(s, a[i])) - 1] == 'f')
                    continue;
                else{
                strcpy(p, &s[strlen(s) - strlen(strstr(s, a[i])) + 1]);
                spatiu(v, strlen(p));
                r = (char *)malloc((strlen(p)+ 1) * sizeof(char));
                strcpy(r, v);
                highlight(p, r);
                strcpy(&h[strlen(h) - strlen(r)], r);
                }
            }
        }
    }
    strcpy(&g[strlen(g) - strlen(h)], h);
}
int main()
{
    char sir[100], sp[100];
    int n, i;
    char *s, *high;
    scanf("%d", &n);
    getchar();
    for(i = 0; i < n; i++)
    {
        gets(sir);
        s = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        strcpy(s, sir);
        spatiu(sp, strlen(sir));
        high = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        strcpy(high, sp);
        highlight(s, high);
        printf("%s\n", s);
        printf("%s\n", high);
        free(s);
        free(high);
    }
    return 0;
}
