#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct dictionar
{
    char *w;
    int pri;
} dict;
void add(dict *v, int i, char *cuv)
{
    v[i].w=(char *)malloc(strlen(cuv)*sizeof(char));
    strcpy(v[i].w, cuv);
    v[i].pri = 0;
}
int find(char *s, dict *d, int n)
{
    int i, k = 0, poz = 0;
    char cuv[20] = "zzzzzzzzzzzzzzzzzzzz";
    for(i = 0; i < n; i++)
    {
        if(strstr(d[i].w, s))
        {
            if(strlen(d[i].w) - strlen(strstr(d[i].w, s)) == 0)
                if(d[i].pri >= poz)
                {
                    if(strcmp(d[i].w, cuv) <= 0)
                    {
                        strcpy(cuv, d[i].w);
                        k = i;
                        poz = d[i].pri;
                    }
                }
        }
    }
    if(strstr(cuv, s))
        return k;
    else return -1;

}
int main()
{
    dict *v;
    int n, i, m, star = 0, k, nr;
    char cuv[20];
    scanf("%d", &n);
    nr = n;
    getchar();
    v = (dict*)malloc(n*sizeof(dict));
    for(i = 0; i < n; i++)
    {
        scanf("%s", cuv);
        add(v, i, cuv);
    }
    scanf("%d", &m);
    getchar();
    for(i = 0; i < m; i++)
    {
        scanf("%s", cuv);
        star = 0;
        if(strchr(cuv,'.') || strchr(cuv,',') ||strchr(cuv,':') ||strchr(cuv,'!') ||strchr(cuv,'?'))
            printf("%s ", cuv);
        else
        {
            if(strstr(cuv,"*"))
            {
                star = 1;
                cuv[strlen(cuv) - strlen(strstr(cuv,"*"))] = NULL;
            }
            k = find(cuv, v, n);
            if(k != -1)
            {
                if(star == 0)
                {
                    printf("%s ", v[k].w);
                    v[k].pri ++;
                }
                else
                    printf("%s ", cuv);
            }
            else
            {
                nr ++;
                v = (dict*)realloc(v, nr*sizeof(dict));
                add(v, nr - 1, cuv);
                v[nr - 1].pri ++;
                printf("%s ", v[nr - 1].w);
            }
        }
    }
    return 0;
}
