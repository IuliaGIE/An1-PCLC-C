#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void highlight(char *s, char *h)
{
    int nr = 0;
    //printf("%s   ", s);
    char a[][20] = {"first of", "for", "for each", "from", "in", "is", "is a", "list of", "unit", "or", "while", "int", "float", "double", "string"};
    for(int i = 0; i < 15; i++)
    {
        if(strchr(s, a[i]))
            printf("%s\n", a[i]);
    }
}
int main()
{
    int n, i;
    char sir[100], sp[100] = {' '};
    char *s, *high;
    scanf("%d", &n);
    for(i = 1; i <= n + 1; i++)
    {
        gets(sir);
        s = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        //high = (char *)malloc((strlen(sir)+ 1) * sizeof(char));
        strcpy(s, sir);
        //strcpy(high, sp);
        //highlight(s, high);
        printf("%s\n", s);
        //printf("%s\n", high);
        //printf("\n");
        //printf("%d ", strlen(sir));
        free(s);
        free(high);
    }
    return 0;
}
