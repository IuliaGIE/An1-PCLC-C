#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct calcule
{
    int cif[4], cod[2];
} calc;
void sum(calc *v, int n)
{
    int nr = 0;
    for(int i = 3; i >= 0; i--)
    {
        nr = nr + v[n + 1].cif[i] + v[n].cif[i];
        v[n + 1].cif[i] = nr % 2;
        nr = nr / 2;
    }
    /*for(int i = 0; i < 4; i++)
    {
        printf("%d", v[n + 1].cif[i]);
    }
    printf("\n");*/
}
void swich(calc *v, int n)
{
    /*for(int i = 0; i < 4; i++)
    {
        printf("%d", v[n].cif[i]);
    }
    printf("\n");
    for(int i = 0; i < 4; i++)
    {
        printf("%d", v[n + 1].cif[i]);
    }
    printf("\n");*/
    int a, b, c;
    a = v[n + 1].cif[0] * 2 + v[n + 1].cif[1];
    b = v[n + 1].cif[2] * 2 + v[n + 1].cif[3];
    //printf("%d %d", a, b);
    c = v[n].cif[b];
    v[n].cif[b] = v[n].cif[a];
    v[n].cif[a] = c;
    //printf("%d ", c);
    /* for(int i = 0; i < 4; i++)
     {
         //v[n + 1].cif[i] = v[n].cif[i];
         printf("%d", v[n].cif[i]);
     }
     printf("\n");
         for(int i = 0; i < 4; i++)
     {
         printf("%d", v[n + 1].cif[i]);
     }
     printf("\n");*/
}
void left(calc *v, int n)
{
    int ct, nr;
    ct = v[n + 1].cif[0] * 8 + v[n + 1].cif[1] * 4 +v[n + 1].cif[2] * 2 + v[n + 1].cif[3];
    ct = ct % 4;
    while(ct)
    {
        nr = v[n].cif[0];
        for(int i = 0; i < 3; i++)
            v[n].cif[i] = v[n].cif[i + 1];
        v[n].cif[3] = nr;
        ct--;
    }
    for(int i = 0; i < 4; i++)
    {
        v[n + 1].cif[i] = v[n].cif[i];
        //printf("%d", v[n + 1].cif[i]);
    }
    //printf("%d", ct);
    /*for(int i = 0; i < 4; i++)
    {
    printf("%d", v[n + 1].cif[i]);
    }
    printf("\n");*/
}
void xor(calc *v, int n)
{
    for(int i = 0; i < 4; i++)
    {
        if(v[n + 1].cif[i] != v[n].cif[i])
            v[n + 1].cif[i] = 1;
        else
            v[n + 1].cif[i] = 0;
    }
    /*for(int i = 0; i < 4; i++)
    {
    printf("%d", v[n + 1].cif[i]);
    }
    printf("\n");*/
}
int main()
{
    calc *v;
    int n, i, ct =  0, k = 0, nr = 0, x;
    unsigned int a;
    scanf("%d%d", &n, &a);
    v = (calc*)malloc((n * 6 + 4)*sizeof(calc));
    int b[32];
    while(ct < n * 6 + 4)
    {
        //printf("%d", a % 2);
        b[ct] = (a % 2);
        a /= 2;
        ct++;
    }
    //printf("%s", b);
    for(i = n * 6 + 3; i >= 0; i--)
    {
        if(k < 6)
        {
            if(ct == 0)
            {
                v[nr].cif[k] = b[i];
                //printf("%d", v[nr].cif[k]);
            }
            else
            {
                v[nr].cod[k - 4] = b[i];
                //printf("%d", v[nr].cod[k - 4]);
            }
            k++;
        }
        if(k == 4)
        {
            //printf(" ");
            ct = 1;
        }
        if(k == 6)
        {
            //printf(" ");
            k = 0;
            ct = 0;
            nr++;
        }
    }
    for(i = 0; i < nr; i++)
    {
        if(v[i].cod[0] == 0 && v[i].cod[1] == 0)
        {
            //printf("sum ");
            sum(v, i);
        }
        if(v[i].cod[0] == 0 && v[i].cod[1] == 1)
        {
            //printf("switch ");
            swich(v, i);
        }
        if(v[i].cod[0] == 1 && v[i].cod[1] == 0)
        {
            //printf("left ");
            left(v, i);
        }
        if(v[i].cod[0] == 1 && v[i].cod[1] == 1)
        {
            //printf("xor ");
            xor(v, i);
        }
    }
    x = v[nr].cif[0] * 8 + v[nr].cif[1] * 4 +v[nr].cif[2] * 2 + v[nr].cif[3];
    /*for(int i = 0; i < 4; i++)
    {
        printf("%d", v[3].cif[i]);
    }*/
    //printf("\n1011 10 0101 00 0001 01 0010");
    //printf("\n %d%d", v[2].cod[0], v[2].cod[1]);
    printf("\n%d", x);
    return 0;
}
