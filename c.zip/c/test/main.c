#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a;
    int i = 5;
    a = i + '0';
    printf("%c", a);
    return 0;
}
