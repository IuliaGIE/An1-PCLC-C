#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
void adunare(char *c1, char *c2, int n)
{
    int s1[1001], s2[1001], s[1001], i, t = 0;
    if(c1[0] == 0)
    {
        for(i = 1; i < n; i ++)
            s1[i] = (int)(c1[i]) - '0';
    }
    else
    {
        for(i = 1; i < n; i ++)
            s1[i] = (-1) * (int)(c1[i]) - '0';
    }
    if(c2[0] == 0)
    {
        for(i = 1; i < n; i ++)
            s2[i] = (int)(c2[i]) - '0';
    }
    else
    {
        for(i = 1; i < n; i ++)
            s2[i] = (-1) * (int)(c2[i]) - '0';
    }
    for(i = 1; i <= n; i++)
    {
        t /= 10;
        s[i] = (t += s1[i] + s2[i] + s[i]) % 10;
    }
    if(t >= 0)
        s[0] = 0;
    else
        s[0] = 1;
    for(i = 0; i <= n; i++)
        c1[i] = (char)(s[i]) + '0';
    printf("\n");
    for(i = 0; i < n; i++)
        printf("%d", s[i]);
}
int main()
{
    int n, r, im;
    char c1[1001], s[1001], c2[1001];
    scanf("%d", &n);
    scanf("%s", &c1);
    scanf("%s", &s);
    while(c1 != '0')
    {
        scanf("%s", &c2);
        if(s[0] == '+') adunare(c1, c2, n);
        //if(s[0] == '-') scadere(c1, c2, n);
        printf("%s\n", c1);
        scanf("%s", &s);
        if(strlen(s) == 1 && s[0] == '0') break;
    }
    return 0;
}
