#include <stdio.h>
#include <stdlib.h>
void adunare(char *c1, char c2[], int n)
{
    int i, re1[1001] = {0}, re2[1001] = {0}, im1[1001] = {0}, im2[1001] = {0}, t = 0;
    reconvert(re1, c1, n);
    reconvert(re2, c2, n);
    imconvert(im1, c1, n);
    imconvert(im2, c2, n);
    for(i = n / 2 - 1; i >= 1; i--)
    {
         re1[i] += re2[i] + t;
        //printf("%d, ", t);
        t = re1[i] / 10;
        re1[i] %= 10;
        //printf("%d, ", re1[i]);
    }
    int ok = 0, poz = 1;
    for(i = 2; i <= n / 2 - 1; i++)
    {

        if(re1[i - 1] > 0 && re1[i] < 0)
            {
                ok = 1;
                poz = i - 1;
            }
        if(ok == 1)
        {
            re1[poz]--;
            re1[i] += 10;
        }
    }
    /*for(i = 1; i <= n / 2 - 1; i++)
        printf("%d, ", re1[i]);
    printf("\n");*/
    t = 0;
    //printf("%d", t);
    for(i = n - 2; i >= n /2 + 1; i--)
    {
        //printf("%d, %d, ", im1[i], im2[i]);
        im1[i] += im2[i] + t;
        t = im1[i] / 10;
        im1[i] %= 10;
        //printf("%d, ", im1[i]);
    }
    ok = 0, poz = n / 2 + 1;
    for(i = n / 2 + 2; i < n - 1; i++)
    {

        if(im1[i - 1] > 0 && im1[i] < 0)
            {
                ok = 1;
                poz = i - 1;
            }
        if(ok == 1)
        {
            im1[poz]--;
            im1[i] += 10;
        }
    }
    /*for(i = n / 2 + 1; i < n - 1; i++)
        printf("%d, ", im1[i]);
    printf("\n");*/
    if(re1[1] >= 0)
            c1[0] = '0';
        else
            c1[0] = '1';
   // printf("%d", im1[n / 2 + 1]);
    if(im1[n / 2 + 1] >= 0)
            c1[n / 2] = '0';
        else
            c1[n / 2] = '1';
    //printf("%c", c1[n/2]);
    reactiv(re1, c1, n);
    imactiv(im1, c1, n);
   // printf("%s", c1);
}
void scadere(char *c1, char c2, int n)
{
    int i, re1[1001] = {0}, re2[1001] = {0}, im1[1001] = {0}, im2[1001] = {0}, t = 0;
    reconvert(re1, c1, n);
    reconvert(re2, c2, n);
    imconvert(im1, c1, n);
    imconvert(im2, c2, n);
}
void reactiv(int s[], char c[], int n)
{
    int i;
    if(c[0] == '0')
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            c[i] = s[i] + '0';
        }
    }
    else
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            c[i] = (s[i]) * (-1) + '0';
        }
    }
}
void imactiv(int s[], char c[], int n)
{
    int i;
    if(c[n / 2] == '0')
        for(i = n / 2 + 1; i < n - 1; i++)
            {
                c[i] = s[i] + '0';
            }
    else
        for(i = n / 2 + 1; i < n - 1; i++)
            {
               c[i] = (s[i]) * (-1) + '0';
            }
}
void reconvert(int s[], char c[], int n)
{
    int i;
    if(c[0] == '0')
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            s[i] = c[i] - '0';
        }
    }
    else
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            s[i] = (c[i] - '0') * (-1);
        }
    }
}
void imconvert(int s[], char c[], int n)
{
    int i;
    if(c[n / 2] == '0')
        for(i = n / 2 + 1; i < n - 1; i++)
            {
                s[i] = c[i] - '0';
            }
    else
        for(i = n / 2 + 1; i < n - 1; i++)
            {
               s[i] = (c[i] - '0') * (-1);
            }
}
int main()
{
    int n, im;
    char c1[1001], s[1001], c2[1001];
    scanf("%d", &n);
    scanf("%s", &c1);
    scanf("%s", &s);
    while(c1 != '0')
    {
        scanf("%s", &c2);
        if(s[0] == '+') adunare(c1, c2, n);
        printf("%s", c1);
        printf("\n");
        //if(s[0] == '-') scadere(c1, c2, n);
        //printf("%s\n", c1);
        scanf("%s", &s);
        if(strlen(s) == 1 && s[0] == '0') break;
    }
}
