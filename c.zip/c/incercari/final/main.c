
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
void adunare(char *c1, char c2[], int n)
{
    int re1, im1, i, sre, sim, re2, im2, re3, im3;
    re1 = re2 = re3 = 0;
    im1 = im2 = im3 = 0;
    if(c1[0] == '0')
            sre = 1;
        else
            sre = -1;
    for(i = 1; i <= n / 2 - 1; i++)
    {
        re1 = re1 * 10 + ((int)(c1[i]) - (int)('0'));
    }
    re1 = re1 * sre;
    if(c1[n / 2] == '0')
        sim = 1;
    else
        sim = -1;
    for(i = n / 2 + 1; i < n - 1; i++)
    {
        im1 = im1 * 10 + ((int)(c1[i]) - (int)('0'));
    }
    im1 = im1 * sim;
    if(c2[0] == '0')
            sre = 1;
        else
            sre = -1;
    for(i = 1; i <= n / 2 - 1; i++)
    {
        re2 = re2 * 10 + ((int)(c2[i]) - (int)('0'));
    }
    re2 = re2 * sre;
    if(c2[n / 2] == '0')
        sim = 1;
    else
        sim = -1;
    for(i = n / 2 + 1; i < n - 1; i++)
    {
        im2 = im2 * 10 + ((int)(c2[i]) - (int)('0'));
    }
    im2 = im2 * sim;
    re3 = re1 + re2;
    im3 = im1 + im2;
    //printf("%d\n", im3);
    if(re3 >= 0)
            c1[0] = '0';
        else
            c1[0] = '1';
    for(i = n / 2 - 1; i >= 1; i --)
    {
        c1[i] = (re3 % 10) + '0';
        re3 = re3 / 10;
    }
    if(im3 >= 0)
            c1[n / 2] = '0';
        else
            {
                c1[n / 2] = '1';
                im3 = im3 * (-1);
            }
    for(i = n - 2; i >= n / 2 + 1; i--)
    {
        c1[i] = (im3 % 10) + '0';
        im3 = im3 / 10;
    }
}
void scadere(char *c1, char c2[], int n)
{
    int re1, im1, i, sre, sim, re2, im2, re3, im3;
    re1 = re2 = re3 = 0;
    im1 = im2 = im3 = 0;
    if(c1[0] == '0')
            sre = 1;
        else
            sre = -1;
    for(i = 1; i <= n / 2 - 1; i++)
    {
        re1 = re1 * 10 + ((int)(c1[i]) - (int)('0'));
    }
    re1 = re1 * sre;
    if(c1[n / 2] == '0')
        sim = 1;
    else
        sim = -1;
    for(i = n / 2 + 1; i < n - 1; i++)
    {
        im1 = im1 * 10 + ((int)(c1[i]) - (int)('0'));
    }
    im1 = im1 * sim;
    if(c2[0] == '0')
            sre = 1;
        else
            sre = -1;
    for(i = 1; i <= n / 2 - 1; i++)
    {
        re2 = re2 * 10 + ((int)(c2[i]) - (int)('0'));
    }
    re2 = re2 * sre;
    if(c2[n / 2] == '0')
        sim = 1;
    else
        sim = -1;
    for(i = n / 2 + 1; i < n - 1; i++)
    {
        im2 = im2 * 10 + ((int)(c2[i]) - (int)('0'));
    }
    im2 = im2 * sim;
    re3 = re1 - re2;
    im3 = im1 - im2;
    if(re3 >= 0)
            c1[0] = '0';
        else
            {
                c1[0] = '1';
                re3 = re3 * (-1);
            }
    for(i = n / 2 - 1; i >= 1; i --)
    {
        c1[i] = (re3 % 10) + '0';
        re3 = re3 / 10;
    }
    if(im3 >= 0)
            c1[n / 2] = '0';
        else
            {
                c1[n / 2] = '1';
                im3 = im3 * (-1);
            }
    for(i = n - 2; i >= n / 2 + 1; i--)
    {
        c1[i] = (im3 % 10) + '0';
        im3 = im3 / 10;
    }
}
int main()
{
    int n, r, im;
    char c1[1001], s[1001], c2[1001];
    scanf("%d", &n);
    scanf("%s", &c1);
    scanf("%s", &s);
    while(c1 != '0')
    {
        scanf("%s", &c2);
        if(s[0] == '+') adunare(c1, c2, n);
        if(s[0] == '-') scadere(c1, c2, n);
        printf("%s\n", c1);
        scanf("%s", &s);
        if(strlen(s) == 1 && s[0] == '0') break;

    }
    return 0;
}
