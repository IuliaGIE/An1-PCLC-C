#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
void adunare(char *c1, char c2[], int n)
{
    int i, re1[1001] = {0}, re2[1001] = {0}, im1[1001] = {0}, im2[1001] = {0}, t = 0;
    re_convert(re1, c1, n);
    re_convert(re2, c2, n);
    im_convert(im1, c1, n);
    im_convert(im2, c2, n);
    for(i = n / 2 - 1; i >= 1; i--)
    {
        t = re1[i] + re2[i] + t;
        re1[i] = t % 10;
        t /= 10;
        /*if(t < 0)
            {
                re1[i] = t % 10 + 10;
                if(t / 10 == 0)
                    t = -1;
                else
                    t /= 10;
            }
        else
            {
                re1[i] = t % 10;
                t /= 10;
            }*/
    }
    t = 0;
    for(i = n - 2; i >= n /2 + 1; i--)
    {
        //printf("%d  ", t);
        t = im1[i] + im2[i] + t;
        printf("%d  ", t);
        /*if(t < 0)
            {
                im1[i] = t % 10 + 10;
                if(t / 10 == 0)
                    t = -1;
                else
                    t /= 10;
            }
        else
            {
                im1[i] = t % 10;
                t /= 10;
            }
            //printf("%d  ", im2[i]);
    }*/
    if(t >= 0)
        im1[n / 2] = 0;
    else
        im1[n / 2] = 1;
    printf("\n");
  // for(i = 0; i <= n / 2 - 1; i ++)
       //printf("%d ", re1[i]);
    //for(i = n / 2; i < n - 1; i++)
      // printf("%d ", im1[i]);
    printf("\n");
}
void re_convert(int s[], char c[], int n)
{
    int i;
    if(c[0] == '0')
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            s[i] = c[i] - '0';
        }
    }
    else
    {
        for(i = 1; i <= n / 2 - 1; i++)
        {
            s[i] = (c[i] - '0') * (-1);
        }
    }
}
void im_convert(int s[], char c[], int n)
{
    int i;
    if(c[n / 2] == '0')
        for(i = n / 2 + 1; i < n - 1; i++)
            {
                s[i] = c[i] - '0';
            }
    else
        for(i = n / 2 + 1; i < n - 1; i++)
            {
               s[i] = (c[i] - '0') * (-1);
            }
}
int main()
{
    int n, r, im;
    char c1[1001], s[1001], c2[1001];
    scanf("%d", &n);
    scanf("%s", &c1);
    scanf("%s", &s);
    while(c1 != '0')
    {
        scanf("%s", &c2);
        if(s[0] == '+') adunare(c1, c2, n);
        //if(s[0] == '-') scadere(c1, c2, n);
        //printf("%s\n", c1);
        scanf("%s", &s);
        if(strlen(s) == 1 && s[0] == '0') break;
    }
    return 0;
}
