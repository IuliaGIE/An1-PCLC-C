#include <stdio.h>
#include <stdlib.h>
int C( int n, int m)
{
    return m == 0 ||
    m == n? 1: C( n - 1, m - 1 ) + C( n - 1, m );
}
int main()
{
    int a, b;
    scanf("%d%d", &a, &b);
    printf("%d", C(a,b));
    return 0;
}
