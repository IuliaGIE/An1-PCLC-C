#include <stdio.h>
#include <stdlib.h>
int suma_cifre(int x)
{
    int sx = 0;
    while(x)
    {
        sx += (x % 10);
        x = x / 10;
    }
    return sx;
}
int main()
{
    int a, b;
    scanf("%d", &a);
    while(a)
    {
        scanf("%d", &b);
        if(b == a % suma_cifre(a))
                printf("(%d, %d) \n", a, b);
        a = b;
    }
    return 0;
}
