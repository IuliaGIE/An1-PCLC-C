#include <stdio.h>
#include <stdlib.h>

int main()
{
    int p, i, j, k;
    scanf("%d", &p);
    for(i = 0; i <= p / 2; i++)
    {
        for(j = i; j <= p - i; j++)
        {
                if(i + j <= p)
                    {
                        k = p - i - j;
                        if(i + j >= k || i + k >= j ||  j + k >= i)
                            if(i <= j && j <= k)
                                printf("%d %d %d \n", i, j, k);
                    }
        }
    }
    return 0;
}
