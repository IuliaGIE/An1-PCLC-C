#include <stdio.h>
#include <stdlib.h>
int prim(int a)
{
    int numarDivizori = 0;
    for(int d = 1; d <= a; d++)
        {
        if(a % d == 0)
            numarDivizori++;
        }
    if(numarDivizori == 2)
        return 1;
    else
        return 0;
}
int main()
{
    int n, f[1000000];
    scanf("%d", &n);
    f[0] = 0;
    f[1] = 1;
    for(int i = 2; i < n; i++)
    {
        f[i] = f[i - 1] + f[i - 2];
        if(prim(f[i])) printf("%d ", f[i]);
    }
    return 0;
}
