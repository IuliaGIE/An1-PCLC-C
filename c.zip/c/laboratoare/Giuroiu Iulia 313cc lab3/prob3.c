#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, nr;
    float x, sx;
    double y, sy;
    scanf("%d%f%lf", &n, &x, &y);
    nr = n / 10;
    for(i = 1; i <= n; i++)
    {
        sx += x;
        sy += y;
        if (i % nr == 0)
            printf("%f %e %f %e \n", sx, sy, sx, sy);
    }
    return 0;
}
