#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, m, i, ct = 0;
    scanf("%d%d", &n, &m);
    for(i = 1; i <= n; i++)
    {
        ct++;
        printf("%d ", i);
        if(i % m == 0) printf("\n");
        if(ct == 24)
        {
            printf("\n"); ct = 0;
        }
    }
    printf("\n");
    return 0;
}
