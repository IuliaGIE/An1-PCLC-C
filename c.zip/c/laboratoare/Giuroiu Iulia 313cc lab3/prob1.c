#include <stdio.h>
#include <stdlib.h>
int main()
{
    int ch, i = 0;
    //scanf("%c", &ch);
    for(ch = 32; ch <= 127; ch++)
        {
            i++;
            printf("%c = %d ", ch, ch);
            if(i == 10)
            {
                i = 0;
                printf("\n");
            }
        }
    return 0;
}
