#include <stdio.h>
#include <stdlib.h>
int cifnr(int a) // cate cifre are a
{
    int ct = 0;
    while(a)
    {
        ct++;
        a /= 10;
    }
    return ct;
}
int numcif(int a, int ciff) // Numărul cifrelor obţinute prin alipirea numerelor până la n, inclusiv.
{
    int nrcif = 0, i;
    for(i = 1; i < ciff; i++)
    {
        nrcif += 9 * pow(10, i - 1) * i;
    }
    nrcif += ((a + 1) - pow(10, i - 1)) * i;
}
int main()
{
    int n, cif;
    scanf("%d", &n);
    cif = cifnr(n);
    printf("%d", numcif(n,cif));
    return 0;
}
