#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double x, esp, r1, r2, rad;
    scanf("%lf%lf", &x, &esp);
    rad = sqrt(x);
    r1 = x / 2;
    r2 = (r1 + x/r1) / 2;
    while(r1 != r2)
    {
        r1 = r2;
        r2 =  r2 = (r1 + x/r1) / 2;
    }
    printf("%lf %lf", rad, r1);
    return 0;
}
