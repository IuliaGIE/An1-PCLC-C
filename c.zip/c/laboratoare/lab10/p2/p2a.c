#include <stdio.h>
#include <stdlib.h>
typedef struct multime
{
    unsigned char a;
    unsigned int n;
}multime;
void initA(struct multime *m){
    m->a = 0;
}
void addA(struct multime *m, int x){
    m->a = m->a | (1 << x);
}
void delA(struct multime *m, int x){
    m->a = m->a & !(1 << x);
}
int containsA(struct multime *m, int x){
    return m->a & (1 << x);
}
void printA(struct multime *m){
    printf("{");
    for(int i = 0; i < 8; i++){
        if(containsA(m, i))
            printf("%d, ", i);
    }
    printf("}");
}
int main()
{
    multime m;
    initA(&m);
    addA(&m, 3);
    addA(&m, 6);
    addA(&m, 2);
    printA(&m);
    delA(&m, 3);
    printA(&m);
    return 0;
}
