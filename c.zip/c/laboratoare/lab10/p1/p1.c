#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double integrala(double (*func) (double x), double a, double b, int n)
{
    double h = (b - a) / n;
    double s = 0, i, x1 = 0, x2 = 0;
    for(i = 1; i <= n; i++)
    {
        x1 = (h / 2) * (i - 1);
        x2 = (h / 2) * i;
        s += (func(x1) + func(x2)) * (h / 2);
    }
    return s;
}
int main()
{
    double pi = M_PI;
    printf("%Integrala de sin este %lf ", integrala(sin, 0, pi, 1000));
    printf("%Integrala de cos este %lf ", integrala(cos, 0, pi, 1000));
    return 0;
}
