#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct multime
{
    unsigned char *a;
    unsigned int n;
}multime;
void init(struct multime *m, int n)
{
        int i, size = n / (8 * sizeof(unsigned char));
        m->n = n;
        if (n % (8 * sizeof(unsigned char)) != 0)
                size++;
        m->a = (unsigned char *) malloc (size * sizeof(unsigned char));
        for (i = 0; i < size; i++)
            m->a = 0;
}
void add(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        m->a[i] = m->a[i] | (1 << ct);
}
void del(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        m->a[i] = m->a[i] & !(1 << ct);
}
int contains(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        return m->a[i] & (1 << ct);
}
void print(struct multime *m)
{
        int i;
        printf("{ ");
        for (i = 0; i < m->n; i++)
                if (contains(m, i))
                        printf("%d ", i);
        printf("}\n");
}
int main()
{
    multime m;
    int nr, x;
    char c[10];
    scanf("%d", &nr);
    init(&m, nr);
    for(int i = 1; i <= nr; i++)
    {
        gets(c);
        if(c[0] == 'A'){
            x = c[2] - '0';
            add(&m, x);
            print(&m);
        }
        if(c[0] == 'D'){
            x = c[2] - '0';
            del(&m, x);
            print(&m);
        }
        if(c[0] == 'A'){
            x = c[2] - '0';
            if(contains(&m, x))
                printf("DA");
            else
                printf("NU");
        }
        if(c[0] == 'P'){
            print(&m);
        }
        getchar();
    }
    return 0;
}
