#include <stdio.h>
#include <stdlib.h>
typedef struct multime
{
    unsigned char *a;
    unsigned int n;
}multime;
void initA(struct multime *m){
    m->a = 0;
}
void init(struct multime *m, int n)
{
        int i, size = n / (8 * sizeof(unsigned char));
        m->n = n;
        if (n % (8 * sizeof(unsigned char)) != 0)
                size++;
        m->a = (unsigned char *) malloc (size * sizeof(unsigned char));
        for (i = 0; i < size; i++)
            m->a = 0;
}
void addA(struct multime *m, int x){
    m->a = m->a | (1 << x);
}
void add(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        m->a[i] = m->a[i] | (1 << ct);
        //m->a[i] = m->a[i] | (1 << ct);
}
void delA(struct multime *m, int x){
    m->a = m->a & !(1 << x);
}
void del(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        m->a[i] = m->a[i] & !(1 << ct);
}
int containsA(struct multime *m, int x){
    return m->a & (1 << x);
}
int contains(struct multime *m, int x)
{
        int i, ct;
        i = x / (8 * sizeof(unsigned char));
        ct = x % (8 * sizeof(unsigned char));
        return m->a[i] & (1 << c);
}
void print(struct multime *m)
{
        int i;
        printf("{ ");
        for (i = 0; i < m->n; i++)
                if (contains(m, i))
                        printf("%d ", i);
        printf("}\n");
}
void printA(struct multime *m){
    printf("{");
    for(int i = 0; i < 8; i++){
        if(containsA(m, i))
            printfA("%d, ", i);
    }
    printfA("}");
}
int main()
{
    multime m;
    initA(&m);
    addA(&m, 3);
    addA(&m, 6);
    addA(&m, 2);
    printA(&m);
    delA(&m, 3);
    printA(&m);
    int nr, x;
    char c;
    for(int i = 1; i <= nr; i++)
    {
        scanf("%c", c);
        if(c == 'A'){
            scanf("%d", x);
            add(&m, x);
            print(&m);
        }
        if(c == 'D'){
            scanf("%d", x);
            del(&m, x);
            print(&m);
        }
        if(c == 'C'){
            scanf("%d", x);
            if(contains(&m, x))
                printf("DA");
            else
                printf("NU");
        }
        if(c == 'P'){
            print(&m);
        }
    }
    return 0;
}
