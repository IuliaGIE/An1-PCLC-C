#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
void panta(int x1, int y1, int x2, int y2, float *m, float *n)
{
    if(x1 == x2)
    {
        *m = INT_MAX;
        *n = 0;
    }
    else if(x1 > x2)
    {
        panta(x2, y2, x1, y1, m, n);
    }
    else
    {
        *m = ((float)(y2 - y1)) / (x2 - x1);
        *n = y1 - (*m) * x1;
    }
}
int main()
{
    int x1, x2, x3, y1, y2, y3;
    float m, n;
    //scanf("%d%d%d%d%d%d",&x1, &x2, &x3, &y1, &y2, &y3);
    scanf("%d%d", &x1, &y1);
    scanf("%d%d", &x2, &y2);
    scanf("%d%d", &x3, &y3);
    panta(x1, y1, x2, y2, &m, &n);
    if((float)(y3) == (float)( m * x3 + n))
        printf("Da\n");
    else
        printf("Nu\n");
    return 0;
}
