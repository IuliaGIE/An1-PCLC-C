#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void unghi(double l[], double u[])
{
    double cos1, cos2, cos3;
    cos1 = (- l[1] * l[1] + l[2]*l[2] + l[3]*l[3]) / (2 * l[2] * l[3]);
    cos2 = (- l[2] * l[2] + l[1]*l[1] + l[3]*l[3]) / (2 * l[1] * l[3]);
    cos3 = (- l[3] * l[3] + l[2]*l[2] + l[1]*l[1]) / (2 * l[2] * l[1]);
    u[1] = acos(cos1) * 180 / M_PI;
    u[2] = acos(cos2) * 180 / M_PI;
    u[3] = acos(cos3) * 180 / M_PI;
}
int main()
{
    double x, y, z, u[3], l[3];
    scanf("%lf%lf%lf", &x, &y, &z);
    l[1] = x;
    l[2] = y;
    l[3] = z;
    unghi(l, u);
    printf("%.3lf %.3lf %.3lf", u[1], u[2], u[3]);
    return 0;
}
