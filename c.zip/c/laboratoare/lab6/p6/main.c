#include <stdio.h>
#include <stdlib.h>
void spirala(int a[][100], int m, int n, int v[]) // copiază elementele lui A în V, în spirală
{
    int x = 0;
    for(int i = 1; i <= m / 2; i++)   //pentru mai multe detalii: https://100din100.netlify.app
    {
        for(int j = i; j <= n - i; ++j) //pentru mai multe detalii: https://100din100.netlify.app
            v[++x] = a[i][j];
        for(int j = i; j <= n - i; ++j) //pentru mai multe detalii: https://100din100.netlify.app
            v[++x] = a[j][n - i + 1];
        for(int j = n - i + 1; j >= i + 1; --j) //pentru mai multe detalii: https://100din100.netlify.app
            v[++x] = a[n - i + 1][j];
        for(int j = n - i + 1; j >= i + 1; --j) //pentru mai multe detalii: https://100din100.netlify.app
            v[++x] =a[j][i];
#
    }
}
void afisare(int v[], int dim) // afişează un vector V, de dimensiune dim
{
    for(int i = 1; i <= dim; i++)
        printf("%d ", v[i]);
}
int main()
{
    int i, j, m, n, a[100][100], v[10000];
    scanf("%d%d", &n, &m);
    for(i = 1; i <= n; i++)
        for(j = 1; j <= m ; j++)
            scanf("%d", &a[i][j]);
    spirala(a, m, n, v);
    afisare(v, n * m);
    return 0;
}
