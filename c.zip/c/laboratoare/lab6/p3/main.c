#include <stdio.h>
#include <stdlib.h>
void identic(int n, int a[], int m, int b[], int c[], int *x)
{
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= m; j++){
            if(a[i] == b[j]){
                (*x)++;
                c[(*x)] = b[j];
            }
        }
    }
}
int main()
{
    int n, m, x = 0, a[1000], b[1000], c[1000];
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    scanf("%d", &m);
    for(int i = 1; i <= m; i++)
        scanf("%d", &b[i]);
    identic(n, a, m, b, c, &x);
    printf("%d\n", x);
    for(int i = 1; i <= x; i++)
        printf("%d ", c[i]);
    return 0;
}
