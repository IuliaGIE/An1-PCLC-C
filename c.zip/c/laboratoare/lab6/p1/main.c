#include <stdio.h>
#include <stdlib.h>
void bubble_sort(int n, int v[])
{
    int i, aux, ok;
    do
    {
        ok = 1;
        for(i = 1; i < n; i ++)
         if(v[i] > v[i + 1])
         {
             aux = v[i];
             v[i] = v[i+1];
             v[i+1] = aux;
             ok = 0;
         }
    } while(!ok);
}
int main()
{
    int n, i, v[10000];
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
        scanf("%d", &v[i]);
    bubble_sort(n, v);
    for(i = 1; i <= n; i++)
        printf("%d ", v[i]);
    return 0;
}
