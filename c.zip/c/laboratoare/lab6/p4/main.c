#include <stdio.h>
#include <string.h>
int comp(char s1[], char s2[])
{
    int n1 = strlen(s1), n2 = strlen(s2), i;
    for( i = 0; i < n1 && i < n2; i++)
            if(s1[i] > s2[i])
                return 1;
            else if(s1[i] < s2[i])
                return -1;
    if(n1 > n2)
        return 1;
    else if(n1 < n2)
            return -1;
    else if(n1 == n2)
            return 0;
    }
int main()
{
    char s1[100], s2[100];
    scanf("%s%s", s1, s2);
    printf("%d", comp(s1, s2));
    return 0;
}
