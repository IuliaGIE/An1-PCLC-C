#include <stdio.h>
#include <stdlib.h>
void transform(int v[], int n, int x)
{
    // o alta forma a cautarii binare
    int st = 0, dr = n - 1, aux, i;
    while(st != dr){
            if(v[i] < x){
                aux = v[i];
                v[i] = v[st];
                v[st] =  aux;
                st++;
                i++;
            }
            else{
                aux = v[i];
                v[i] = v[dr];
                v[dr] =  aux;
                dr--;
            }
    }
}
int main()
{
    int n, x, v[100], i;
    scanf("%d%d", &n, &x);
    for(i = 1; i <= n; i++)
        scanf("%d", &v[i]);
    transform(v, n, x);
    for(i = 1; i <= n; i++)
        printf("%d ", v[i]);
    return 0;
}
