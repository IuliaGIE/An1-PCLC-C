#include <stdio.h>
#include <stdlib.h>
typedef struct {
     float r, i;
} complex;
complex adunare(complex a, complex b)
{
    complex c;
    c.r = a.r + b.r;
    c.i = a.i + b.i;
    return c;
}
complex scadere(complex a, complex b)
{
    complex c;
    c.r = a.r - b.r;
    c.i = a.i - b.i;
    return c;
}
complex inmultire(complex a, complex b)
{
    complex c;
    c.r = a.r * b.r - a.i * b.i;
    c.i = a.r * b.i + b.r * a.i;
    return c;
}
complex putere(complex a, int putere)
{
    complex c;
    c.r = 1;
    c.i = 0;
    for(int i = 1; i <= putere; i++)
        c = inmultire(c, a);
    return c;
}
void scrie(complex a)
{
    printf("(%f,%f)\n", a.r, a.i);
}
int main()
{
    complex a, b, c;
    scanf("%f%f%f%f", &a.r, &b.r, &a.i, &b.i);
    c = adunare(a, b);
    scrie(c);
    c = scadere(a, b);
    scrie(c);
    c = inmultire(a, b);
    scrie(c);
    c = putere(a, 2);
    scrie(c);
    return 0;
}
