#include <stdio.h>
#include <stdlib.h>

int main()
{
    struct punct
        {
            double x, y;
        }p;
    scanf("%lf%lf", &p.x, &p.y);
    printf("(%.2lf,%.2lf)", p.x, p.y);
    return 0;
}
