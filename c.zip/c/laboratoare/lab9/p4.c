#include <stdio.h>
#include <stdlib.h>
typedef struct vector
{
        int *v;
        int cap;
        int n;
} vector;
void init_vector(vector *a, int nr)
{
    a->cap = nr;
    a->n = 0;
    a->v = (int*) malloc(nr * sizeof(int));
}
void adauga_vector(vector *a, int ad)
{
    if(a->n >= a->cap)
    {
        a->v = (int*) realloc(a->v, 2 * a->cap * sizeof(int));
        a->cap *= 2;
    }
    a->v[a->n] = ad;
        a->n++;
}
void scrie_vector(vector *a)
{
    for(int i = 1; i < a->n; i++)
        printf("%d ", a->v[i]);
}
int main()
{
    vector a;
    init_vector(&a, 10);
    for(int i = 0; i <= 8; i++)
        adauga_vector(&a, i);
    scrie_vector(&a);
    printf("\n");
    return 0;
}
