#include <stdio.h>
#include <stdlib.h>
#include <math.h>
float dist(int x1, int y1, int x2, int y2)
{
    float d = 0;
    d = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    return d;
}
int main()
{
    int n, x[100], y[100], v[100], i, j, x1, x2, y1, y2;
    float dmax = -1, d;
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
        scanf("%d%d", &x[i], &y[i]);
    for(i = 1; i < n; i++)
    {
        for(j = i + 1; j <= n; j++)
        {
             d = dist(x[i], y[i], x[j], y[j]);
             if(d > dmax)
             {
                 dmax = d;
                 x1 = x[i];
                 x2 = x[j];
                 y1 = y[i];
                 y2 = y[j];
            }
        }
    }
    printf("%d %d\n%d %d\n%f", x1, y1, x2, y2, dmax);
    return 0;
}
