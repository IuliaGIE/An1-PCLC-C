#include <stdio.h>
#include <stdlib.h>
int prim(int n)
{
    int d, prim = 1;
    if(n == 0) return 0;
    if(n == 1) return 1;
    for(int i = 2; i * i <= n; i++)
        if(n % i == 0)
    {
        prim = 0;
        break;
    }
    if(prim == 1) return 1;
             else return 0;
}
int main()
{
    int i, n;
    scanf("%d", &n);
    for(i = 1; i <= n / 2; i++)
    {
        if(prim(i) == 1 && prim(n - i) == 1)
            printf("%d + %d\n", i, n - i);
    }
    return 0;
}
