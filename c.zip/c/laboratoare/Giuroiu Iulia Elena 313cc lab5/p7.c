#include <stdio.h>
#include <stdlib.h>
int transforma(int n)
{
    int v[10] = {0}, i, x = 0;
    while(n)
    {
        v[n % 10] ++;
        n /= 10;
    }
    if(v[0] >= 1)
    {
        for(i = 9; i >= 0; i--)
        {
            while(v[i])
            {
                x = x * 10 + i;
                v[i] --;
            }
        }
    }
    else
    {
        for(i = 1; i <= 9; i++)
        {
            while(v[i])
            {
                x = x * 10 + i;
                v[i] --;
            }
        }
    }
    return x;
}
int main()
{
    int n;
    scanf("%d", &n);
    printf("%d", transforma(n));
    return 0;
}
