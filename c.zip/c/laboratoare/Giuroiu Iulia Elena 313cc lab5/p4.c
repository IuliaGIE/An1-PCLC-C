#include <stdio.h>
#include <stdlib.h>
int cmmdc(int a, int b)
 {
     int aux, r;
     if( a == 0 && b == 0) return -1;
    else
    {
        if(b > a)
        {
            aux = a;
            a = b;
            b = aux;
        }
        while( b != 0)
        {
            r = a % b;
            a = b;
            b = r;
        }
        return a;
    }
 }
int main()
{
    int x1, y1, x2, y2, x;
    scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
    x = (y1 * y2) / cmmdc(y1, y2);
    //printf("Hello world!\n");
    printf("%d %d \n%d %d", x1 * (x / y1), x, x2 * (x / y2), x);
    return 0;
}
