#include <stdio.h>
#include <stdlib.h>
int factorial(int n)
{
    int f = 1;
    for(int i = 1; i <= n; i ++)
        f *= i;
    return f;
}
double putere(double x, int n)
{
    double p = 1;
    for(int i = 1; i <= n; i ++)
        p = p * x;
    return p;
}
double taylor(double x, int n)
{
    double t = 1;
    for(int i = 1; i <= n; i++)
        t = t + putere(x, i)/factorial(i);
    return t;
}
int main()
{
    int n;
    double x;
    scanf("%lf%d", &x, &n);
    printf("%.4lf", taylor(x, n));
    return 0;
}
