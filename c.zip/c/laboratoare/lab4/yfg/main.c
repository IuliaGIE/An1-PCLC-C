#include <stdio.h>
#include <stdlib.h>
void det(int x, int ct)
{
    printf("Cifrele din numar sunt ");
    while(x){
        ct++;
        printf("%d ", x % 10);
        x = x / 10;
    }
    printf("\n");
    printf("Numarul de cifre este %d", ct);

}
int main()
{
    int n;
    scanf("%d", &n);
    int x = n, ct = 0;
    if(n / 100 >= 9) printf("Este mai mare de 3 cifre"); // un numar de forma abc : 100 = a ( unde a este o cifra cuprinsa intre 0-9 )
        else{
            det(x, ct);
            }
    return 0;
}
