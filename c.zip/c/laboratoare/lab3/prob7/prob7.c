#include <stdio.h>
#include <stdlib.h>
#include <math.h>
float rec(double x, int n)
{
    double t[100];
    int k;
    t[0] == 1;
    for(k = 1; k <= n; k++)
        t[k] = t[k-1] * x / k;
    return t[n];
}
int main()
{
    double x, ESP;
    int n;
    scanf("%d%e%e", &n, &x, &ESP);
    printf("%lf %lf %lf", rec(x,n), exp(x), pow(2.718,x));
    return 0;
}
