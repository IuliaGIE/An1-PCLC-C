#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    double x, a, pol = 0;
    int n, i;
    scanf("%lf%d", &x, &n);
    for(i = 0; i <= n; i++){
        scanf("%lf", &a);
        pol += a * pow(x, n - i);
    }
    printf("%-8.2fl", pol);
    return 0;
}
