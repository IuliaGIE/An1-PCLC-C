#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, v[100], i, des, cre, cons;
    des = cre = cons = 1;
    scanf("%d", &n);
    scanf("%d", &v[1]);
    for(i = 2; i <= n; i++){
        scanf("%d", &v[i]);
        if(v[i - 1] < v[i])
            cre++;
        else if(v[i - 1] > v[i])
            des++;
        else if(v[i - 1] = v[i])
            cons++;
    }
    if(n == cre)
        printf("crescator");
    else if(n == des)
        printf("descrescator");
    else if(n == cons)
        printf("constant");
    else
        printf("neordonat");
    return 0;
}
