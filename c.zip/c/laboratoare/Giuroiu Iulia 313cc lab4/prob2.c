#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N, v[100], neg = 0, i;
    scanf("%d", &N);
     for (i = 0; i < N; i++) {
        scanf("%d", &v[i]);
        if(v[i] < 0) neg++;
    }
    printf("%d %d", neg, N - neg);
    return 0;
}
