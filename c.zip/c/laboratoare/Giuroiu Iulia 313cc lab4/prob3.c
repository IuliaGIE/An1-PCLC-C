#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int N, M, a[100][100], i, j, maxi = -100000, mini = 100000;
    scanf("%d%d", &N, &M);
    for(i = 0; i < N; i++){
        maxi = -100000;
        for(j = 0; j < M; j++){
            scanf("%d", &a[i][j]);
            if(maxi < a[i][j])
                maxi = a[i][j];
        }
        if(mini > maxi)
            mini = maxi;
    }
    printf("%d", mini);
    return 0;
}
