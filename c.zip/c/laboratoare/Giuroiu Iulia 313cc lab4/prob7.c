#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N, v[100], i, in, sf, sec = 0, maxx = 0, poz;// in = unde incepe secventa, sf = unde se termina
    scanf("%d", &N);
    scanf("%d", &v[1]);
    for(i = 2; i <= N; i++){
        scanf("%d", &v[i]);
        if(v[i - 1] < v[i]){
                sec++;
                if(sec > maxx) maxx = sec, poz = i - 1;
        }
        else
            sec = 0;
    }
    for(i = poz - maxx + 1; i <= poz + 1; i++)
        printf("%d ", v[i]);
    return 0;
}
