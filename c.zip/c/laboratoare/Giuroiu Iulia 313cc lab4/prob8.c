#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, v[100], i, vs[100], smax = -1000000, s = -10000;
    int st = 0, dr = 1, p = 1; // p = poz. de inceput a secv
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        scanf("%d", &v[i]);
        if(s < 0){
                s = v[i];
                p = i;
        }
        else
            s += v[i];
        if(s > smax){
            smax = s;
            st = p;
            dr = i;
        }
    }
    for(i = st; i <= dr; i++)
            printf("%d ", v[i]);
    return 0;
}
