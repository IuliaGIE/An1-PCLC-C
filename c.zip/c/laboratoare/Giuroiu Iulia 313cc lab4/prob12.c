#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, m, i, b, e, v, j, w[1000000];
    scanf("%d%d", &n, &m);
    //printf("%d%d", n, m);
    for(i = 0; i < n; i++){
        w[i] = 0;
    }
    for(i = 0; i < m; i++){
        scanf("%d%d%d", &b, &e, &v);
        //printf("%d%d%d", b, e, v);
        for(j = b; j <= e; j++){
            w[j] += v;
        }
    }
    for(i = 0; i < n; i++){
        printf("%d ", w[i]);
    }
    return 0;
}
