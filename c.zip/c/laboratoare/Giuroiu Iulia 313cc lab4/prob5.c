#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[1000], b[1000], c[2000], n, m , i, j, k;
    scanf("%d", &n);
    for(i = 1; i <= n; i ++)
        scanf("%d", &a[i]);
    scanf("%d", &m);
    for(i = 1; i <= m; i ++)
        scanf("%d", &b[i]);
    i = 1; j = 1; k = 0;
    while (i <= n && j <= m)
        if (a[i] < b[j])
            c[++ k] = a[i], i = i + 1;
        else
            c[++ k] = b[j], j = j + 1;
    if(i > n)
        for(i = j; i <= m; i ++)
            c[++ k] = b[i];
    else
        for(j = i; j <= n; j ++)
            c[++ k] = a[j];
    for(i = 1; i <= n + m; i ++)
        printf("%d ", c[i]);
    return 0;
}
