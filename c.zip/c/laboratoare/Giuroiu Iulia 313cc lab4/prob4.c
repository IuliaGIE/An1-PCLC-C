#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, m, p, q, i, j, a[100][100], b[100][100], c[100][100];
    scanf("%d%d", &n, &m);
    for(i = 1; i <= n; i++)
        for(j = 1; j <= m; j++)
            scanf("%d", &a[i][j]);
    scanf("%d%d", &p, &q);
    for(i = 1; i <= p; i++)
        for(j = 1; j <= q; j++)
            scanf("%d", &b[i][j]);
    if(m != p){
        printf("imposibil");
        return 0;
    }
    else{
        for(i = 1; i <= n; i++)
            for(j = 1; j <= q; j++){
                    c[i][j] = 0;
                    for(int k = 1; k <= m; k++)
                        c[i][j] += a[i][k] * b[k][j];
            }
        }
    printf("%d%d", n, q);
    for(i = 1; i <= n; i++){
            for(j = 1; j <= q; j++)
                    printf("%d ", c[i][j]);
		printf("\n");
    }
    return 0;
}
