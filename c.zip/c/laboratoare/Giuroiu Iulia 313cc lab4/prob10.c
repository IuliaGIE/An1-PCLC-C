#include <stdio.h>
#include <stdlib.h>

int main()
{
    double v[100], aux;
    int w[1000], m, i, j, n;
    scanf("%d", &n);
    for(i = 1; i <= n; i ++)
        scanf("%lf", &v[i]);
    for(i = 1; i < n; i ++)
        for(j = i + 1; j <= n; j ++)
            if(v[i] > v[j])
            {
                aux = v[i];
                v[i] = v[j];
                v[j] = aux;
            }
    // am sortat elementele primului vector pentru a cauta
    // mai usor pe intervalele de pe al doile vector
    scanf("%d", &m);
    scanf("%d", &w[1]);
    for(i = 2; i <= m; i ++)
    {
        scanf("%d", &w[i]);
        if(w[i - 1] > w[i])
        {
            printf("Error");
            return 0;
        }
    }
    for(i = 1; i < m; i ++){
        int ct = 0;
        for(int ii = 1; ii <= n; ii ++){
            if(w[i] < v[ii] && w[i + 1] > v[ii]){
                    ct++;
                    //printf("%lf ", v[ii]);
            }
        }
       printf("%d ", ct);
    }
    return 0;
}
