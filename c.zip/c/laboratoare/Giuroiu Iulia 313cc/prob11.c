#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, c, dlt;
    scanf("%f%f%f", &a, &b, &c);
    if(a == 0 && b == 0 && c == 0) printf("Infinit");
    else if(a == 0 && b == 0 && c != 0) printf("Nu exista solutii");
    else if(a == 0)
    {
        printf("%f", (-c)/b);
    }
    dlt = b * b - 4 * a * c;
    if(dlt > 0)
    {
        printf("%5.2f ", (-b + sqrt(dlt)) / (2 * a));
        printf("%5.2f ", (-b - sqrt(dlt)) / (2 * a));
    }
    else if(dlt == 0) printf("%5.2f ", (-b)/(2 * a));
    else if(dlt < 0) printf("Nu exista solutii");
    return 0;
}
