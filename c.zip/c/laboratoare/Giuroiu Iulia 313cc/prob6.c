#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, c;
    scanf("%lf%lf%lf", &a, &b, &c);
    if(a == b && b == c) printf("echilateral");
    else if(a * a == b * b + c * c || b * b == a * a + c * c || c * c == a * a + b * b)
    {
        if(a == b || b == c || a == c) printf("dreptunghic isoscel");
                                  else printf("dreptunghic");
    }
    else if(a == b || b == c || a == c) printf("isoscel");
                              else printf("oarecare");
    return 0;
}
