#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, d;
    scanf("%d%d%d", &a, &b, &c);
    if(a < b && a < c)
        {
        if(b < c) printf("%d %d %d", a, b, c);
        else printf("%d %d %d", a, c, b);
        }
    if(a > b && b < c)
        {
        if(a < c) printf("%d %d %d", b, a, c);
        else printf("%d %d %d", b, c, a);
        }
    if(c < b && a > c)
        {
        if(a < b) printf("%d %d %d", c, a, b);
        else printf("%d %d %d", c, b, a);
        }
    return 0;
}
