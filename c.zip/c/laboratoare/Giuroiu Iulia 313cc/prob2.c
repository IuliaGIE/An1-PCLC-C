#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a, b, c;
    scanf("%f%e%g", &a, &b, &c);
    printf("numerele sunt %f , %e si %g", a, b, c);
    return 0;
}
