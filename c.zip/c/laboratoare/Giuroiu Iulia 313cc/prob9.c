#include <stdio.h>
#include <stdlib.h>

int main()
{
    int h, m, s;
    scanf("%d%d%d", &h, &m, &s);
    printf("%02d:%02d:%02d", h, m, s);
    return 0;
}
