#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n;
    srand(4);
    for(int i = 1; i <=3; i++)
    {
        n = rand();
        printf("%d ", n);
    }
    return 0;
}
