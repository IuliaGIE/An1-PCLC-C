#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, d;
    scanf("%d%d%d%d", &a, &b, &c, &d);
    if(a > b && a > c && a > d) printf("maximul %d ", a);
    if(a < b && b > c && b > d) printf("maximul %d ", b);
    if(c > b && a < c && c > d) printf("maximul %d ", c);
    if(d > b && d > c && a < d) printf("maximul %d ", d);
    if(a < b && a < c && a < d) printf("minimul %d ", a);
    if(a > b && b < c && b < d) printf("minimul %d ", b);
    if(c < b && a > c && c > d) printf("minimul %d ", c);
    if(d < b && d < c && a > d) printf("minimul %d ", d);
    return 0;
}
