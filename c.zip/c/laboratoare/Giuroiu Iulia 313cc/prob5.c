#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    if(a + b + c != 0)
    {
        if(a < b + c || b < a + c || c < a + b) printf("Da");
                                           else printf("Nu");
    }
    return 0;
}
