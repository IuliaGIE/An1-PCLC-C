#include <stdio.h>
#include <string.h>
char* substr(char *src, int n, char *dest)
{
    strncpy(dest, src, n);
    if(n <= strlen(src))
        dest[n] = '\0';

}
int main()
{
    char s1[100], s2[100];
    int poz, nr;
    scanf("%s%d%d", s1, &poz, &nr);
    substr(s1 + poz, nr, s2);
    printf("%s\n", s2);
    return 0;
}
