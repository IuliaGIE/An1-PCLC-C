#include <stdio.h>
#include <stdlib.h>
void count(int n, int *v, int *zero, int *poz, int *neg)
{
    for(int i = 1; i <= n; i++)
    {
        if(v[i] > 0)
            {
                (*poz) ++;
            }
            else if(v[i] < 0)
            {
                (*neg) ++;
            }
            else (*zero) ++;

    }
}
int main()
{
    int n, v[100], nule = 0, pozi = 0, nega = 0, i;
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
        scanf("%d", &v[i]);
    count(n, v, &nule, &pozi, &nega);
    printf("nule: %d \npozitive: %d \nnegative:  %d \n", nule, pozi, nega);
    return 0;
}
