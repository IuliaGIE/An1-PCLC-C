#include <stdio.h>
#include <stdlib.h>
char *next(char *from, char *word)
{
        //nu luam in calcul caracterele care sunt diferite de '\0' sau de litere mici
        while ((*from) != '\0' && ((*from) < 'a' || (*from) > 'z'))
            from++;
        //daca nu mai sunt litere in from
        if ((*from) == '\0') return NULL;
        //aflam pozitia spatiului dintre caractere
        char *p = from;
        while ((*p) != '\0' && (*p) >= 'a' && (*p) <= 'z')
            p++;
        //copiem in word (p-from) caractere
        strncpy(word, from, p - from);
        word[p - from] = '\0';
        return p;
}
int main()
{
        char s[100], *p, cuv[100];
        gets(s);
        for (p = next(s, cuv); p != NULL; p = next(p, cuv))
                printf("%s ", cuv);
        return 0;
}
