#include <stdio.h>
#include <string.h>
char *strdel(char *p, int n)
{
    if(strlen(p) <= n) // nu exista mai mult de n caractere care incep de la p
    {
        *p = '\0';
    }
    strcpy(p, p + n);
}
char *strins(char *p, char *s)
{
    char *c = strdup(p);
    strcpy(p, s);
    strcat(p, c);
}
int main()
{
    char s[3000], sloc[20], snou[20];
    gets(s);
    scanf("%s%s", sloc, snou);
    char *p;
    for(p = strstr(s, sloc); p != NULL; p = strstr(p + strlen(snou), sloc))
    {
        strdel(p, strlen(sloc));
        strins(p, snou);
    }
    printf("%s\n", s);
    return 0;
}
